print("[PhunKeys][BOOT][DEBUG2] ENTER shared/PhunKeys_Shared.lua")

PhunKeys = PhunKeys or {
    module = "PhunKeys",
    command = "packVehicle",
    cutKeyCommand = "cutVehicleKey",
    grantAccessCommand = "GrantAccess",
    lockCommand = "Lock",
    accessResultCommand = "accessResult",
    playSoundCommand = "playSound",
    itemType = "PhunKeys.VehicleKeySeller",
    boxItemType = "PhunKeys.TransmutationBox",
    maxDistance = 4
}

PhunKeys.buildTag = "DEBUG2-2026-09-24"

AcceptItemFunction = AcceptItemFunction or {}

function AcceptItemFunction.AcceptVanillaCarKey(container, item)
    local fullType = item and item:getFullType() or "<nil>"
    print("[PhunKeys][ACCEPT][DEBUG2] AcceptVanillaCarKey invoked item=" .. tostring(fullType))
    -- Keep the legacy callback name for existing boxes; recipes validate their own inputs.
    return item ~= nil
end

print("[PhunKeys][SHARED][Load][DEBUG2] PhunKeys_Shared.lua loaded; build=" .. tostring(PhunKeys.buildTag) .. " boxItemType=" .. tostring(PhunKeys.boxItemType))

-- Direct contents only: miscellaneous items and additional blanks can remain in the box.
function PhunKeys.buildingKeyInBox(box, requiredId)
    local inventory = box and box:getInventory()
    if not inventory then return nil end
    local items, chosen = inventory:getItems(), nil
    for i = 0, items:size() - 1 do
        local item = items:get(i)
        -- Accept building keys and blank building keys only.
        local fullType = item and item:getFullType()
        if item and (fullType == "Base.Key1" or fullType == "Base.Key_Blank")
            and (requiredId == nil or item:getID() == requiredId)
            and (not chosen or item:getID() < chosen:getID()) then
            chosen = item
        end
    end
    return chosen
end

-- Key creation follows vanilla passenger-door locks, independently of access protection.
function PhunKeys.isKeyVehicleLocked(vehicle)
    if not vehicle then return false end
    for seat = 0, vehicle:getMaxPassengers() - 1 do
        local part = vehicle:getPassengerDoor(seat)
        local door = part and part:getDoor()
        if door and door:isLocked() then return true end
        local secondPart = vehicle:getPassengerDoor2(seat)
        local secondDoor = secondPart and secondPart:getDoor()
        if secondDoor and secondDoor:isLocked() then return true end
    end
    return false
end

-- Shared selection rules; the server independently repeats this at execution.
function PhunKeys.nearestKeyVehicle(player)
    if not player then return nil end
    local cell = getCell()
    local vehicles = cell and cell:getVehicles()
    if not vehicles then return nil end
    local nearest, bestDistance = nil, PhunKeys.maxDistance * PhunKeys.maxDistance
    local iterator = vehicles:iterator()
    while iterator:hasNext() do
        local vehicle = iterator:next()
        if vehicle and vehicle:getSquare() and vehicle:getScript()
            and vehicle:getKeyId() >= 0
            and math.floor(player:getZ()) == math.floor(vehicle:getZ()) then
            local dx, dy = player:getX() - vehicle:getX(), player:getY() - vehicle:getY()
            local distance = dx * dx + dy * dy
            if distance <= bestDistance and (not nearest or distance < bestDistance
                or vehicle:getId() < nearest:getId()) then
                nearest, bestDistance = vehicle, distance
            end
        end
    end
    return nearest
end

return PhunKeys
